package halo.query.annotation;

/**
 * 默认class，没有实际使用意义，只是在HaloSelect HaloCount中作为默认值使用
 * 
 * @author akwei
 */
public class DefClass {
}
